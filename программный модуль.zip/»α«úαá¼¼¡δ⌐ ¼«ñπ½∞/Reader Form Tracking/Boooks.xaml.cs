﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Reader_Form_Tracking
{
    /// <summary>
    /// Логика взаимодействия для Boooks.xaml
    /// </summary>
    public partial class Boooks : Window
    {
        visitor vis1;
        MainWindow manw;
        DBEntities bd;
        public Boooks(DBEntities db,visitor vis, MainWindow mw)
        {
            InitializeComponent();
            bd = db;
            manw = mw;
            vis1 = vis;
            famnam.Content= vis1.ФИО;
            Refresh();
        }

        public void Refresh()
        {
            dGrid.ItemsSource=(from x in bd.Book where x.Номер_росетителя==vis1.Номер_формуляра select x).ToList();
            dGrid0.ItemsSource=(from x in bd.Note where x.Посетитель==vis1.Номер_формуляра select x).ToList();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (dGrid.SelectedIndex == -1) { MessageBox.Show("Книга не выбрана"); return; }
            if (((Book)dGrid.SelectedItem).Дата_возврата.ToString()!="") { MessageBox.Show("Книга уже возвращена"); return; }
            ((Book)dGrid.SelectedItem).Дата_возврата = DateTime.Now;
            bd.SaveChanges();
            Refresh();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            AddBook adb = new AddBook(bd,vis1, this);
            adb.Show();
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            manw.Refresh();
        }

        private void Window_Closing(object sender, EventArgs e)
        {
            manw.Refresh();
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            Тщеув not = new Тщеув(bd,vis1,this);
            not.ShowDialog();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            if (dGrid0.SelectedIndex == -1) { MessageBox.Show("Заметка не выбрана"); return; }
            bd.Note.Remove(((Note)dGrid0.SelectedItem));
            bd.SaveChanges();
            Refresh();
        }
    }
}
