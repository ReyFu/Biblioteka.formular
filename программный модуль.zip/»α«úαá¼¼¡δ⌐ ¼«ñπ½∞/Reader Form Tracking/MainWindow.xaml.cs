﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using System.Data.Common;

namespace Reader_Form_Tracking
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        static DBEntities bd = new DBEntities();


        public MainWindow()
        {
            InitializeComponent();
            BackUp();
            Refresh();
        }

        public void Refresh()
        {
            List<Chelik> r = new List<Chelik>();
            var rr = (from x in bd.visitor select x).ToList();

            foreach (var item in rr)
            {

                Chelik chel = new Chelik();
                chel.born = item.Год_рождения;
                chel.age = ((int)DateTime.Now.Subtract(item.Год_рождения).TotalDays / 360).ToString();
                chel.FIO = item.ФИО;
                string[] nam = chel.FIO.Split(' ');
                chel.familis = nam[0];
                try
                {
                    chel.imya = nam[1];
                    chel.ochestvo = nam[2];
                }
                catch { }

                var rrr = (from a in item.Book select a.Дата_возврата).ToList();
                foreach (var item1 in rrr)
                {
                    if (!item1.HasValue)
                    {
                        chel.dolg = true;
                        break;
                    }
                }
                r.Add(chel);
            }
            var rrrr = r;

            if (fioTB.Text != "")
            {
                 rrrr = (from x in r where x.FIO.ToLower().Contains(fioTB.Text) select x).ToList();
            }
            if (ageTB.Text != "")
            {
                rrrr = (from x in r where x.age.Contains(ageTB.Text) select x).ToList();
            }

            if (Cbussy == 2)
            {   
                rrrr = (from x in r where x.dolg == true select x).ToList();
            }
            if (Cbussy == 1)
            {
                rrrr = (from x in r where x.dolg == false select x).ToList();
            }

            dGrid.ItemsSource = rrrr;
            dGrid.SelectedIndex = 0;
        }

        public class Chelik
        {
            public string FIO { get; set; }
            public string familis { get; set; }
            public string imya { get; set; }
            public string ochestvo { get; set; }
            public string age { get; set; }
            public DateTime born { get; set; }
            public bool dolg { get; set; }
        }

        void BackUp()
        {
            if (!Directory.Exists(@"D:\backup")) { Directory.CreateDirectory(@"D:\backup"); }
            using (var connection = new SqlConnection("Data Source=DESKTOP-UU3BUSF\\SQLEXPRESS;" + "Initial Catalog=Reader_form_DB;" + "Integrated Security=SSPI;"))
            using (var command = new SqlCommand( @"BACKUP DATABASE Reader_form_DB  TO DISK = N'D:\backup\" + "Backup_" + DateTime.Now.ToString().Replace(':', '-') + ".BAK' WITH FORMAT;  ", connection))
            {
                try
                {
                    connection.Open();
                }
                catch
                {
                    MessageBox.Show("Подключение к базе данных отсутствует!", "Ошибка");
                }

                command.ExecuteNonQuery();
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            AddUser usad = new AddUser(bd,this,new visitor(),false);
            usad.ShowDialog();
        }

        private void DelButton_Click(object sender, RoutedEventArgs e)
        {
            Chelik deletec= (Chelik)dGrid.SelectedItem;

            if (deletec.dolg) { MessageBox.Show("У читателя есть задолженность"); return; }

            MessageBoxResult result = MessageBox.Show("Вы уверены?", "Удаление", MessageBoxButton.YesNo, MessageBoxImage.Stop);
            if (result != MessageBoxResult.Yes) { return; }

            visitor deletec1 = (from x in bd.visitor where x.ФИО == deletec.FIO && x.Год_рождения == deletec.born select x).ToArray()[0];

            var notec = (from x in bd.Note where x.Посетитель == deletec1.Номер_формуляра select x).ToList();
            foreach (var item in notec)
            {
                bd.Note.Remove(item);
            }

            var bookec = (from x in bd.Book where x.Номер_росетителя == deletec1.Номер_формуляра select x).ToList();
            foreach (var item in bookec)
            {
                bd.Book.Remove(item);
            }

            bd.visitor.Remove(deletec1);
            bd.SaveChanges();
            Refresh();
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            Refresh(); 
        }
        int Cbussy=0;
        private void TextBox_TextChanged(object sender, RoutedEventArgs e)
        {
           if ((sender as CheckBox).IsChecked ?? false) { Cbussy++; } else { Cbussy--; }
           Refresh(); 
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            Chelik deletec = (Chelik)dGrid.SelectedItem;
            AddUser usad = new AddUser(bd, this, (from x in bd.visitor where x.ФИО == deletec.FIO && x.Год_рождения == deletec.born select x).ToArray()[0],true) ;
            usad.ShowDialog();
        }
        private void dGrid_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            Chelik deletec = (Chelik)dGrid.SelectedItem;
            Boooks bok = new Boooks(bd,(from x in bd.visitor where x.ФИО == deletec.FIO && x.Год_рождения == deletec.born select x).ToArray()[0],this);
            bok.ShowDialog();
        }
    }
}
