﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Reader_Form_Tracking
{
    /// <summary>
    /// Логика взаимодействия для AddBook.xaml
    /// </summary>
    public partial class AddBook : Window
    {
        visitor vis;
        Boooks bksss;
        DBEntities bd;
        public AddBook(DBEntities db,visitor visitor, Boooks bks)
        {
            InitializeComponent();
            bd = db;
            bksss =bks;
            vis = visitor;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (namTB.Text == "") { MessageBox.Show("Введите название книги");return; }
            if (nomTB.Text == "") { MessageBox.Show("Введите номер книги");return; }

            Book book = new Book();
            book.Номер_росетителя = vis.Номер_формуляра;
            book.Код_книги=nomTB.Text;
            book.Название_книги = namTB.Text;
            book.Дата_выдачи = DateTime.Now;

            bd.Book.Add(book);
            bd.SaveChanges();
            bksss.Refresh();
            Close();
        }
    }
}
