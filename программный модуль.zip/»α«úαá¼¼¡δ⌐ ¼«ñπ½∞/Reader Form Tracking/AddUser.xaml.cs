﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Reader_Form_Tracking
{
    /// <summary>
    /// Логика взаимодействия для AddUser.xaml
    /// </summary>
    public partial class AddUser : Window
    {
        DBEntities bd;
        MainWindow mw;
        visitor vis1 = new visitor();
        bool pochemu1;
        public AddUser(DBEntities db, MainWindow wind, visitor visit, bool pochemu)
        {
            InitializeComponent();
            pochemu1 = pochemu;
            if (pochemu)
            {
                windav.Title = "Рерактирование данных посетителя";
                button1.Content = "Сохранить изменения";
                vis1 = visit;

                adrTB.Text = vis1.Адрес.Trim(' ');
                nazTB.Text = vis1.Национальность.Trim(' ');
                ageDP.SelectedDate = vis1.Год_рождения;
                whopasTB.Text = vis1.кем_выдан_паспорта.Trim(' ');
                whenDP.SelectedDate = vis1.когда_выдан_паспорта;
                npasTB.Text = vis1.Номер_паспорта.Trim(' ');
                profTB.Text = vis1.Профессия.Trim(' ');
                eduTB.Text = vis1.Образование.Trim(' ');
                spasTB.Text = vis1.Серия_паспорта.Trim(' ');
                phoTB.Text = vis1.Телефон.Trim(' ');
                learTB.Text = vis1.Учебное_заведение.Trim(' ');
                fioTB.Text = vis1.ФИО.Trim(' ');
            }
            mw = wind;
            bd = db;
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            if (!pochemu1)
            {
                visitor vis = new visitor();

                if (fioTB.Text == "") { MessageBox.Show("Введите ФИО"); return; }
                if (ageDP.SelectedDate == null) { MessageBox.Show("Введите дату рождения"); return; }

                vis.Адрес = adrTB.Text;
                vis.Национальность = nazTB.Text;
                vis.Год_рождения = ageDP.SelectedDate ?? DateTime.Now.Date;
                vis.Год_создания_формуляра = DateTime.Now.Date;
                vis.кем_выдан_паспорта = whopasTB.Text;
                vis.когда_выдан_паспорта = whenDP.SelectedDate;
                vis.Номер_паспорта = npasTB.Text;
                vis.Профессия = profTB.Text;
                vis.Образование = eduTB.Text;
                vis.Серия_паспорта = spasTB.Text;
                vis.Телефон = phoTB.Text;
                vis.Учебное_заведение = learTB.Text;
                vis.ФИО = fioTB.Text;

                bd.visitor.Add(vis);
            }
            else
            {
                if (fioTB.Text == "") { MessageBox.Show("Введите ФИО"); return; }
                if (ageDP.SelectedDate == null) { MessageBox.Show("Введите дату рождения"); return; }

                vis1.Адрес = adrTB.Text;
                vis1.Национальность = nazTB.Text;
                vis1.Год_рождения = ageDP.SelectedDate ?? DateTime.Now.Date;
                vis1.Год_создания_формуляра = DateTime.Now.Date;
                vis1.кем_выдан_паспорта = whopasTB.Text;
                vis1.когда_выдан_паспорта = whenDP.SelectedDate;
                vis1.Номер_паспорта = npasTB.Text;
                vis1.Профессия = profTB.Text;
                vis1.Образование = eduTB.Text;
                vis1.Серия_паспорта = spasTB.Text;
                vis1.Телефон = phoTB.Text;
                vis1.Учебное_заведение = learTB.Text;
                vis1.ФИО = fioTB.Text;
            }
            bd.SaveChanges();
            mw.Refresh();
            Close();
        }
    }
}
