﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Reader_Form_Tracking
{
    public partial class Тщеув : Window
    {
        DBEntities bd;
        visitor vis1;
        Boooks bks;
        public Тщеув(DBEntities db, visitor vis, Boooks bks)
        {
            InitializeComponent();
            textbox1.Focus();
            bd = db;
            vis1 = vis;
            this.bks = bks;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Note not = new Note();
            not.Текст = textbox1.Text;
            not.Посетитель = vis1.Номер_формуляра;

            vis1.Note.Add(not);
            bd.SaveChanges();
            bks.Refresh();
            Close();
        }
    }
}
